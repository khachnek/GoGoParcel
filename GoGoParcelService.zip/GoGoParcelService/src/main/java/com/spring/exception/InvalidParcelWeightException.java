package com.spring.exception;

public class InvalidParcelWeightException extends Exception {
	
	public InvalidParcelWeightException(String msg) {
		super(msg);
		//fill the code
	}

}
